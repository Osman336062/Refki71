package com.example.sep1.model.dataManagement;

import com.example.sep1.model.AnimalForSale;

public class AnimalsForSaleManagement
{
  private String textFilePath;

  public static void addAnimalForSale(AnimalForSale animalForSale)
  {


  }
}

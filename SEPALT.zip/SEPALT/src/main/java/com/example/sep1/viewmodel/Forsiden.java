package com.example.sep1.viewmodel;

import javafx.application.Application;
import javafx.stage.Stage;

public class Forsiden extends Application
{

    @Override public void start(Stage primaryStage) throws Exception
    {

    }

}

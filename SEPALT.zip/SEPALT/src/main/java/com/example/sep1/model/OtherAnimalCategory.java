package com.example.sep1.model;

import java.time.LocalDate;

public class OtherAnimalCategory extends AnimalInformation
{


  public OtherAnimalCategory(boolean isMale, LocalDate birthday, String name)
  {
    super(isMale, birthday, name);
  }


}

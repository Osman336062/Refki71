package com.example.sep1.model;

public class Costumer
{
  private String name;
  private int phoneNumber;
  private String eMail;

  public Costumer(AnimalForSale animalForSale, AnimalInCare animalInCare, String name, int phoneNumber, String eMail)
  {
    this.name = name;
    this.phoneNumber = phoneNumber;
    this.eMail = eMail;
  }

  public String getName()
  {
    return name;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  public int getPhoneNumber()
  {
    return phoneNumber;
  }

  public void setPhoneNumber(int phoneNumber)
  {
    this.phoneNumber = phoneNumber;
  }

  public String geteMail()
  {
    return eMail;
  }

  public void seteMail(String eMail)
  {
    this.eMail = eMail;
  }
}

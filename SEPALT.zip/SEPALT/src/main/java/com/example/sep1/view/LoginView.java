package com.example.sep1.view;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class LoginView
{
  @FXML private Label welcomeText;







}
